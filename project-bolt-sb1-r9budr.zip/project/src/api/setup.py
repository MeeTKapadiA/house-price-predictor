from setuptools import setup, find_packages

setup(
    name="house-price-predictor",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[
        'flask==3.0.2',
        'flask-cors==4.0.0',
        'scikit-learn==1.4.1.post1',
        'numpy==1.26.4',
        'pandas==2.2.1'
    ],
)