from flask import Flask, request, jsonify
from flask_cors import CORS
from model import HousePriceModel
import logging
import sys
from logging.handlers import RotatingFileHandler

app = Flask(__name__)
CORS(app)

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Add file handler
handler = RotatingFileHandler('api.log', maxBytes=10000, backupCount=1)
handler.setLevel(logging.INFO)
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
handler.setFormatter(formatter)
logger.addHandler(handler)

# Add console handler
console_handler = logging.StreamHandler(sys.stdout)
console_handler.setLevel(logging.INFO)
console_handler.setFormatter(formatter)
logger.addHandler(console_handler)

@app.route('/health', methods=['GET'])
def health_check():
    return jsonify({'status': 'healthy'}), 200

@app.route('/predict', methods=['POST'])
def predict():
    try:
        data = request.get_json()
        if not data:
            return jsonify({'error': 'No data provided'}), 400
        
        # Validate required fields
        required_fields = ['squareFeet', 'bedrooms', 'bathrooms', 'location']
        missing_fields = [field for field in required_fields if field not in data]
        if missing_fields:
            return jsonify({'error': f'Missing required fields: {", ".join(missing_fields)}'}), 400
        
        # Validate data types
        try:
            square_feet = float(data['squareFeet'])
            bedrooms = float(data['bedrooms'])
            bathrooms = float(data['bathrooms'])
            location = str(data['location']).lower()
        except (ValueError, TypeError):
            return jsonify({'error': 'Invalid data types provided'}), 400
        
        model = HousePriceModel()
        prediction = model.predict(
            square_feet,
            bedrooms,
            bathrooms,
            location
        )
        
        logger.info(f'Successful prediction: {prediction}')
        return jsonify({'prediction': prediction})
        
    except Exception as e:
        logger.error(f'Error during prediction: {str(e)}')
        return jsonify({'error': str(e)}), 400

if __name__ == '__main__':
    logger.info('Starting Flask server on port 8000...')
    try:
        app.run(host='0.0.0.0', port=8000)
    except Exception as e:
        logger.error(f'Failed to start server: {str(e)}')