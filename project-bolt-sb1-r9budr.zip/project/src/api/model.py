import numpy as np
from sklearn.preprocessing import StandardScaler

class HousePriceModel:
    def __init__(self):
        # Initialize with more realistic coefficients
        self.scaler = StandardScaler()
        self.features = ['square_feet', 'bedrooms', 'bathrooms']
        
        # Base coefficients (more realistic weights)
        self.coefficients = {
            'square_feet': 150,  # $150 per sq ft
            'bedrooms': 25000,   # $25k per bedroom
            'bathrooms': 35000,  # $35k per bathroom
        }
        
        self.location_multipliers = {
            'urban': 1.4,      # 40% premium for urban
            'suburban': 1.15,  # 15% premium for suburban
            'rural': 1.0,      # base price for rural
        }
        
        # Base price considering market conditions
        self.base_price = 200000  # $200k base price

    def _normalize_features(self, features):
        return {
            name: (value - self.feature_means.get(name, 0)) / self.feature_stds.get(name, 1)
            for name, value in features.items()
        }

    def predict(self, square_feet, bedrooms, bathrooms, location):
        try:
            # Input validation
            if square_feet < 100 or square_feet > 10000:
                raise ValueError("Square feet must be between 100 and 10,000")
            if bedrooms < 1 or bedrooms > 10:
                raise ValueError("Number of bedrooms must be between 1 and 10")
            if bathrooms < 1 or bathrooms > 10:
                raise ValueError("Number of bathrooms must be between 1 and 10")
            if location.lower() not in self.location_multipliers:
                raise ValueError("Invalid location type")

            # Calculate base price from features
            price = self.base_price
            price += square_feet * self.coefficients['square_feet']
            price += bedrooms * self.coefficients['bedrooms']
            price += bathrooms * self.coefficients['bathrooms']
            
            # Apply location multiplier
            price *= self.location_multipliers[location.lower()]
            
            # Add some realistic variation (±5%)
            variation = np.random.uniform(0.95, 1.05)
            price *= variation
            
            return round(price, 2)
            
        except Exception as e:
            raise ValueError(f"Prediction error: {str(e)}")