export interface HousePredictionData {
  squareFeet: number;
  bedrooms: number;
  bathrooms: number;
  location: string;
}

export interface PredictionResponse {
  prediction: number;
}

export interface PredictionError {
  error: string;
}