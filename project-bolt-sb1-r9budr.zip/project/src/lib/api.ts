import { HousePredictionData, PredictionResponse, PredictionError } from './types';
import { API_URL } from './constants';

export async function predictHousePrice(data: HousePredictionData): Promise<number> {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 10000); // Increased timeout to 10 seconds

    const response = await fetch(`${API_URL}/predict`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
      signal: controller.signal
    });
    
    clearTimeout(timeoutId);
    
    if (!response.ok) {
      const errorData = await response.json() as PredictionError;
      throw new Error(errorData.error || `HTTP error! status: ${response.status}`);
    }
    
    const responseData = await response.json() as PredictionResponse;
    
    if (typeof responseData.prediction !== 'number') {
      throw new Error('Invalid prediction format received from server');
    }
    
    return responseData.prediction;
  } catch (error) {
    if (error instanceof Error) {
      if (error.name === 'AbortError') {
        throw new Error('Server not responding. Please try again in a few moments.');
      }
      throw error;
    }
    throw new Error('An unexpected error occurred');
  }
}