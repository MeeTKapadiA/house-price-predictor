export const API_URL = 'http://localhost:8000';

export const LOCATION_OPTIONS = [
  { value: 'urban', label: 'Urban' },
  { value: 'suburban', label: 'Suburban' },
  { value: 'rural', label: 'Rural' },
] as const;

export const INITIAL_FORM_DATA = {
  squareFeet: 1500,
  bedrooms: 3,
  bathrooms: 2,
  location: 'suburban',
} as const;