import React, { useState } from 'react';
import { Home, Loader2, AlertCircle } from 'lucide-react';
import { predictHousePrice } from '../lib/api';
import { FormInput } from './FormInput';
import { FormSelect } from './FormSelect';
import { PredictionResult } from './PredictionResult';
import { LOCATION_OPTIONS, INITIAL_FORM_DATA } from '../lib/constants';
import type { HousePredictionData } from '../lib/types';

export function PredictionForm() {
  const [formData, setFormData] = useState<HousePredictionData>(INITIAL_FORM_DATA);
  const [prediction, setPrediction] = useState<number | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const validateForm = (data: HousePredictionData): string | null => {
    if (data.squareFeet < 100 || data.squareFeet > 10000) {
      return 'Square feet must be between 100 and 10,000';
    }
    if (data.bedrooms < 1 || data.bedrooms > 10) {
      return 'Number of bedrooms must be between 1 and 10';
    }
    if (data.bathrooms < 1 || data.bathrooms > 10) {
      return 'Number of bathrooms must be between 1 and 10';
    }
    return null;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const validationError = validateForm(formData);
    if (validationError) {
      setError(validationError);
      return;
    }

    setLoading(true);
    setError(null);
    setPrediction(null);
    
    try {
      const result = await predictHousePrice(formData);
      setPrediction(result);
    } catch (err) {
      console.error('Form submission error:', err);
      setError(err instanceof Error ? err.message : 'Failed to get prediction');
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: name === 'squareFeet' || name === 'bedrooms' || name === 'bathrooms' 
        ? Number(value) 
        : value
    }));
    setError(null); // Clear error when input changes
  };

  return (
    <div className="w-full max-w-md p-6 bg-white rounded-xl shadow-lg">
      <div className="flex items-center justify-center mb-8">
        <Home className="w-8 h-8 text-blue-600 mr-2" />
        <h2 className="text-2xl font-bold text-gray-800">House Price Predictor</h2>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <FormInput
          label="Square Feet"
          type="number"
          name="squareFeet"
          value={formData.squareFeet}
          onChange={handleInputChange}
          min="100"
          max="10000"
          required
        />

        <FormInput
          label="Bedrooms"
          type="number"
          name="bedrooms"
          value={formData.bedrooms}
          onChange={handleInputChange}
          min="1"
          max="10"
          required
        />

        <FormInput
          label="Bathrooms"
          type="number"
          name="bathrooms"
          value={formData.bathrooms}
          onChange={handleInputChange}
          min="1"
          max="10"
          step="0.5"
          required
        />

        <FormSelect
          label="Location"
          name="location"
          value={formData.location}
          onChange={handleInputChange}
          options={LOCATION_OPTIONS}
          required
        />

        {error && (
          <div className="p-3 bg-red-50 border border-red-200 rounded-md">
            <div className="flex items-center space-x-2">
              <AlertCircle className="w-5 h-5 text-red-500" />
              <p className="text-sm text-red-600">{error}</p>
            </div>
          </div>
        )}

        <button
          type="submit"
          disabled={loading}
          className="w-full flex items-center justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {loading ? (
            <Loader2 className="w-5 h-5 animate-spin" />
          ) : (
            'Predict Price'
          )}
        </button>
      </form>

      {prediction !== null && <PredictionResult prediction={prediction} />}
    </div>
  );
}