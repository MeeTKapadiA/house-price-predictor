import React from 'react';
import { DollarSign } from 'lucide-react';

interface PredictionResultProps {
  prediction: number;
}

export function PredictionResult({ prediction }: PredictionResultProps) {
  return (
    <div className="mt-6 p-4 bg-gray-50 rounded-lg">
      <div className="flex items-center justify-between">
        <span className="text-sm font-medium text-gray-600">Estimated Price:</span>
        <div className="flex items-center">
          <DollarSign className="w-5 h-5 text-green-600 mr-1" />
          <span className="text-xl font-bold text-green-600">
            {prediction.toLocaleString('en-US', {
              style: 'currency',
              currency: 'USD',
              minimumFractionDigits: 0,
              maximumFractionDigits: 0,
            })}
          </span>
        </div>
      </div>
    </div>
  );
}